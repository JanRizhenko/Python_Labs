i = 1
while i <= 18:
    print(i)
    i += 1