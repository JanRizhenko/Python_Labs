import math

a = int(input("Введіть перше число: "))
b = int(input("Введіть друге число: "))

gcd = math.gcd(a, b)
print("Найбільший спільний дільник (НСД):", gcd)
