
for i in range(18,29):
    print(i, end=", ")