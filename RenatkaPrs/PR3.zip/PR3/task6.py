num = 18

for i in range(1,11):
    product = num * i
    print(num, " x ", i, " = ", product)