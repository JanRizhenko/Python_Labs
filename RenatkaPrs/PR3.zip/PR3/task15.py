n = int(input("Введіть число: "))
total = sum(range(1, n + 1))
print("Сума чисел від 1 до", n, "дорівнює:", total)
