number = input("Введіть число: ")

if number == number[::-1]:
    print("Це паліндром.")
else:
    print("Це не паліндром.")
