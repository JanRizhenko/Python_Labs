char = input("Введіть символ: ")

if '0' <= char <= '9':
    print("Yes")
else:
    print("No")
