def first_and_last(word):
    return word[0].lower() == word[-1].lower()

print(first_and_last("America"))
print(first_and_last("Europe"))
