text = input("Введіть рядок: ")

for index in range(len(text)):
    print(index, text[index])
