text = input("Введіть рядок: ")

print("У верхньому регістрі:", text.upper())
print("У нижньому регістрі:", text.lower())
