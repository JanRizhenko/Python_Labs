text = input("Введіть рядок: ")

text = text.replace('!', '?')

text = text.replace('?', '??')

print("Модифікований текст:", text)
