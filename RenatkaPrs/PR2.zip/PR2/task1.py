num = int(input("Введіть ціле число: "))

if num > 0:
    print(num, "є додатнім числом")
elif num < 0:
    print(num, "є від'ємним числом")
else:
    print("Введене число є нулем")