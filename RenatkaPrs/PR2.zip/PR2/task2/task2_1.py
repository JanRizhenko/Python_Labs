num = int(input("Введіть ціле число: "))

if num % 2 == 0:
    print(num, "є парним числом")
else:
    print(num, "є непарним числом")