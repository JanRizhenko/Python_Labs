a = float(input("Введіть перше число: "))
b = float(input("Введіть друге число: "))
c = float(input("Введіть третє число: "))

if a + b == c:
    print("Так")
else:
    print("Ні")