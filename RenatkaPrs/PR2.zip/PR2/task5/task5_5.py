a = float(input("Введіть перше число: "))
b = float(input("Введіть друге число: "))

if a > b:
    print("Перше число більше.")
elif a < b:
    print("Друге число більше.")
else:
    print("Числа рівні.")