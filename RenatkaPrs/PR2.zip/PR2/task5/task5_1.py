a = float(input("Введіть перше число: "))
b = float(input("Введіть друге число: "))

if a > b:
    print("Різниця:", a - b)
else:
    print("Сума:", a + b)
