x = float(input("Введіть перше число: "))
y = float(input("Введіть друге число: "))

if x > 10 and y > 10:
    print("Добуток:", x * y)
else:
    print("Сума:", x + y)