num1 = int(input("Введіть перше число: "))
num2 = int(input("Введіть друге число: "))


print(num1 * num2 < 50)