num1 = float(input("Введіть перше число: "))
num2 = float(input("Введіть друге число: "))

sum = num1 + num2

print("Сума чисел:", sum)
