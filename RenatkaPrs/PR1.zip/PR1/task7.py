hours_worked = float(input("Введіть кількість відпрацьованих годин: "))
hourly_rate = float(input("Введіть розмір годинної оплати: "))

salary = hours_worked * hourly_rate

print("Заробітна плата:", salary)
