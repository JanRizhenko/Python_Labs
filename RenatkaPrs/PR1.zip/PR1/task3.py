num1 = float(input("Введіть перше число: "))
num2 = float(input("Введіть друге число: "))
num3 = float(input("Введіть третє число: "))

avg = (num1 + num2 + num3) / 3

avg = round(avg, 2)

print("Середнє арифметичне чисел:", avg)
