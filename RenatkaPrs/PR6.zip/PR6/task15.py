e2u = {
    "cat": "кіт",
    "dog": "собака",
    "frog": "жаба"
}

for eng, ukr in e2u.items():
    print(f"{eng}: {ukr}")
