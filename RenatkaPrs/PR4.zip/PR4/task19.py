numbers = list(map(int, input("Введіть числа через пробіл: ").split()))

min_num = min(numbers)

print(f"Найменше число: {min_num}")
