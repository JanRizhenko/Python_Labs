numbers = [3, 7, 2, 8, 5, 9, 1]

print("Елементи списку в зворотному порядку:")
for num in reversed(numbers):
    print(num, end=" ")
