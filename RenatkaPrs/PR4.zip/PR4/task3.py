variant = 18
numbers = [10, -5, 3, -18, 12, 6, -9, 18, -20, 25, -8, 15]

sum = 0
for num in numbers:
    sum += num
    print(" a = ", num, " sum = ", sum)

print("Сума елементів списку:", sum)
