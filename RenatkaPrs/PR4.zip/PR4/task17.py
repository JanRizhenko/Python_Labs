filename = input("Введіть повне ім'я файлу: ")

extension = filename.split('.')[-1]

print("Розширення файлу:", extension)