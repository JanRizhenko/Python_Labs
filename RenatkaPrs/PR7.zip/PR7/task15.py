square = lambda x: x ** 2

num = int(input("Введіть число: "))
result = square(num)
print(f"Квадрат числа {num} дорівнює {result}")
