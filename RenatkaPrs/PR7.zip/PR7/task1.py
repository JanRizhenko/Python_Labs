def greet():
    print(f"Вітаю!")

greet()
