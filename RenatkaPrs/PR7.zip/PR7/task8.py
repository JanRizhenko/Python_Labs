def absolute_value(number):
    return abs(number)

num = float(input("Введіть число: "))

result = absolute_value(num)

print(f"Модуль числа {num} дорівнює {result}")
