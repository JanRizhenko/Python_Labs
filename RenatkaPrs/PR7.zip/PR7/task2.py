def greet(name):
    print(f"Вітаю, {name.upper()}!")

name = input("Введіть ваше ім'я: ")
greet(name)
