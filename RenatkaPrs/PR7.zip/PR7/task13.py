def sum_of_any_numbers(*args):
    return sum(args)

result = sum_of_any_numbers(1, 2, 3, 4, 5)
print(f"Сума чисел: {result}")
