def power(base, exponent=2):
    return base ** exponent

result = power(3, 3)
print(f"3 в степені 3 дорівнює: {result}")

result_default = power(4)
print(f"4 в степені 2 дорівнює: {result_default}")
